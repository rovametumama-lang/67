package com.cart3r.sixtyseven

import android.app.Activity
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity() {

    private val bg = Color.rgb(8, 8, 8)
    private val panel = Color.rgb(20, 13, 13)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 160, 160)
    private val prefs by lazy { getSharedPreferences("67_settings", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var gameList: LinearLayout
    private lateinit var searchInput: EditText
    private var launchableApps: List<ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        launchableApps = loadLaunchableApps()
        showHome()
    }

    private fun loadLaunchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun baseScreen(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(12))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(18))
        }
        header.addView(label("CART3R.JAILBREAK  /  ANDROID", 11, red, true))
        header.addView(label(title, 27, white, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        })
        header.addView(label(subtitle, 13, muted, false))
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        nav.addView(navButton("INICIO") { showHome() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        nav.addView(navButton("JUEGOS") { showGames() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        nav.addView(navButton("AJUSTES") { showSettings() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        baseScreen("67 GAME OPTIMIZER", "Herramientas seguras para preparar tu sesión de juego")
        val (availableMb, totalMb) = memoryInfo()
        val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
        val batteryPct = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            .takeIf { it in 0..100 }?.toString()?.plus("%") ?: "No disponible"

        content.addView(card {
            addView(label("ESTADO DEL DISPOSITIVO", 12, red, true))
            addView(label("Memoria disponible: $availableMb MB", 18, white, true).apply {
                setPadding(0, dp(10), 0, dp(4))
            })
            addView(label("Memoria total aproximada: $totalMb MB", 13, muted, false))
            addView(label("Batería: $batteryPct", 13, muted, false).apply {
                setPadding(0, dp(5), 0, 0)
            })
            addView(label("Datos informativos; no representan los FPS del juego.", 11, muted, false)
                .apply { setPadding(0, dp(10), 0, 0) })
        })

        content.addView(actionCard(
            "ABRIR UN JUEGO",
            "Busca una aplicación instalada y ejecútala.",
            "VER JUEGOS"
        ) { showGames() })

        content.addView(actionCard(
            "MODO DE SESIÓN",
            "Guarda tus preferencias dentro de 67. No modifica procesos de otros juegos.",
            if (prefs.getBoolean("session_mode", false)) "ACTIVADO" else "DESACTIVADO"
        ) {
            val next = !prefs.getBoolean("session_mode", false)
            prefs.edit().putBoolean("session_mode", next).apply()
            showHome()
        })

        content.addView(actionCard(
            "AJUSTES DE BATERÍA",
            "Abre los ajustes oficiales de batería de Android.",
            "ABRIR AJUSTES"
        ) { openSystemSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) })

        content.addView(actionCard(
            "AJUSTES DE PANTALLA",
            "Configura la tasa de refresco o el brillo si tu dispositivo lo permite.",
            "ABRIR AJUSTES"
        ) { openSystemSettings(Settings.ACTION_DISPLAY_SETTINGS) })

        content.addView(label(
            "IMPORTANTE: Android no permite que una app normal aumente por la fuerza los FPS, libere la RAM de otros juegos o cambie sus gráficos internos. Para esas opciones utiliza los ajustes del fabricante o del propio juego.",
            12, muted, false
        ).apply { setPadding(dp(4), dp(14), dp(4), dp(18)) })
    }

    private fun showGames() {
        baseScreen("TUS APLICACIONES", "Selecciona una aplicación para abrirla")
        searchInput = EditText(this).apply {
            hint = "Buscar aplicación..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            singleLine = true
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(panel, 14, Color.rgb(75, 35, 35))
        }
        content.addView(searchInput, LinearLayout.LayoutParams(-1, dp(50)))
        gameList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(gameList)
        renderGames("")
        searchInput.addTextChangedListener(SimpleTextWatcher { renderGames(it) })
    }

    private fun renderGames(filter: String) {
        if (!::gameList.isInitialized) return
        gameList.removeAllViews()
        val matches = launchableApps.filter {
            it.loadLabel(packageManager).toString().contains(filter, ignoreCase = true)
        }
        if (matches.isEmpty()) {
            gameList.addView(label("No se encontraron aplicaciones.", 14, muted, false)
                .apply { setPadding(4, dp(20), 4, dp(20)) })
        }
        matches.forEach { info ->
            val appName = info.loadLabel(packageManager).toString()
            val pkg = info.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel, 14)
                setPadding(dp(12), dp(10), dp(10), dp(10))
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(6), 0)
            }
            textCol.addView(label(appName, 15, white, true))
            textCol.addView(label(pkg, 10, muted, false))
            row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
            val open = Button(this).apply {
                text = "ABRIR"
                textSize = 10f
                setTextColor(white)
                isAllCaps = false
                background = rounded(red, 10)
                setOnClickListener { launchApp(pkg) }
            }
            row.addView(open, LinearLayout.LayoutParams(dp(76), dp(42)))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(9)
            gameList.addView(row, lp)
        }
    }

    private fun showSettings() {
        baseScreen("AJUSTES", "Preferencias locales de la aplicación")
        val notifications = prefs.getBoolean("tips", true)
        val tips = Switch(this).apply {
            text = "Mostrar consejos de rendimiento"
            textSize = 14f
            setTextColor(white)
            isChecked = notifications
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("tips", checked).apply()
            }
        }
        content.addView(card { addView(tips) })
        content.addView(actionCard(
            "INFORMACIÓN DE LA APLICACIÓN",
            "Consulta los permisos y detalles de 67 en Android.",
            "VER"
        ) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName"))
            startActivity(intent)
        })
        content.addView(actionCard(
            "VOLVER A DETECTAR APLICACIONES",
            "Actualiza la lista de aplicaciones con acceso de inicio.",
            "ACTUALIZAR"
        ) {
            launchableApps = loadLaunchableApps()
            showGames()
        })
        content.addView(label("67 versión 1.0.0 · Android 8.0 o superior", 12, muted, false)
            .apply { setPadding(dp(4), dp(18), 0, 0) })
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) {
            Toast.makeText(this, "No se puede abrir esta aplicación.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "La aplicación no está disponible.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSystemSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun memoryInfo(): Pair<Long, Long> {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        return Pair(info.availMem / (1024 * 1024), info.totalMem / (1024 * 1024))
    }

    private fun actionCard(title: String, description: String, button: String, action: () -> Unit): View {
        return card {
            addView(label(title, 14, red, true))
            addView(label(description, 12, muted, false).apply {
                setPadding(0, dp(7), 0, dp(12))
            })
            val b = Button(this@MainActivity).apply {
                text = button
                textSize = 11f
                setTextColor(white)
                isAllCaps = false
                background = rounded(red, 11)
                setOnClickListener { action() }
            }
            addView(b, LinearLayout.LayoutParams(-1, dp(44)))
        }
    }

    private fun card(build: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 17, Color.rgb(65, 31, 31))
            setPadding(dp(15), dp(15), dp(15), dp(15))
            build()
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(11)
            layoutParams = lp
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun navButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 10f
            isAllCaps = false
            setTextColor(white)
            background = rounded(panel, 12, Color.rgb(65, 31, 31))
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(val onText: (String) -> Unit) :
    android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        onText(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
