# 67 – Android Game Optimizer

Aplicación Android nativa en Kotlin, sin dependencias externas de librerías.

## Requisitos
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.11.1 (Android Studio puede descargarlo/configurarlo)

## Abrir y compilar
1. Descomprime el proyecto.
2. En Android Studio elige **Open** y selecciona la carpeta `67-android-game-optimizer`.
3. Espera a que termine la sincronización de Gradle.
4. Instala Android SDK 35 si Android Studio lo solicita.
5. Conecta un móvil con depuración USB o crea un emulador.
6. Pulsa **Run**.

## Crear APK
En Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
El APK de depuración se genera normalmente en:
`app/build/outputs/apk/debug/app-debug.apk`

## Qué hace
- Muestra memoria total/disponible del dispositivo y porcentaje de batería.
- Detecta aplicaciones con actividad de inicio visible para la app.
- Permite buscar y abrir esas aplicaciones.
- Guarda una preferencia local de modo de sesión.
- Abre los ajustes oficiales de batería, pantalla y detalles de la app.

## Límites reales de Android
Una aplicación normal no puede terminar procesos de otras apps, limpiar la caché de otros juegos, forzar FPS, cambiar sus ajustes gráficos internos ni garantizar menos lag. La memoria que muestra es información general del dispositivo, no una medición de FPS ni una garantía de rendimiento. La tasa de refresco y el modo de juego dependen del fabricante, la versión de Android y el juego.

La consulta de aplicaciones usa un filtro de intención `MAIN` + `LAUNCHER` en `<queries>` y no solicita `QUERY_ALL_PACKAGES`.
